// Сервер beatcut/ без зависимостей: статика, нарезки и задачи нарезки.
// /clips/list.json → { dir, files:[имя…] } из последней папки ${TMPDIR:-/tmp}/beatcut-clips/<дата-время>/,
// /clips/<имя> – сам файл, /clips/status – инструменты и последняя папка,
// POST /clips/jobs {text, mode, per, len, height} → задача, GET /clips/jobs/<id>?from=N – её события,
// POST /clips/jobs/<id>/cancel – отмена. Задачу выполняет randclip (yt-dlp + ffmpeg), отдельный проект: см. tools/randclip.js.
// Запуск: node beatcut/tools/serve.js [порт] (по умолчанию 8794, только 127.0.0.1; HOST=… чтобы слушать шире).
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os');
const { loadRandclip } = require('./randclip.js');
const { normalize, DEFAULTS } = require('../src/fetch-model.js');

const ROOT = path.join(__dirname, '..', 'src');
const CLIPS = process.env.BEATCUT_CLIPS || path.join(process.env.TMPDIR || os.tmpdir(), 'beatcut-clips');
const MAX_BODY = 64 * 1024;
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.mp4': 'video/mp4', '.svg': 'image/svg+xml', '.png': 'image/png', '.wasm': 'application/wasm' };

function latestDir(base) {
  let names;
  try { names = fs.readdirSync(base, { withFileTypes: true }).filter(d => d.isDirectory()).map(d => d.name).sort(); }
  catch { return null; }
  return names.length ? path.join(base, names[names.length - 1]) : null;
}
function listClips(base) {
  const dir = latestDir(base);
  if (!dir) return { dir: null, files: [] };
  return { dir, files: fs.readdirSync(dir).filter(f => /\.mp4$/i.test(f)).sort() };
}
// Путь внутри корня без выхода наружу; иначе null.
function safeJoin(root, rel) {
  const p = path.normalize(path.join(root, decodeURIComponent(rel)));
  return p === root || p.startsWith(root + path.sep) ? p : null;
}
function send(res, code, body, type = 'text/plain; charset=utf-8') { res.writeHead(code, { 'Content-Type': type }); res.end(body); }
function sendJson(res, code, data) { send(res, code, JSON.stringify(data), TYPES['.json']); }
// no-cache: dev-сервер, правки файлов должны попадать на страницу без hard reload
function sendFile(res, file) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return send(res, 404, 'not found');
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'no-cache' });
    fs.createReadStream(file).pipe(res);
  });
}

// ---------- инструменты и движок ----------
// Инструменты проверяет сам randclip; нет самого randclip – об этом тоже говорим как о недостающем.
function checkTools(load = loadRandclip) {
  try { return load().checkTools(); }
  catch (e) {
    return { ytdlp: false, ffmpeg: false, ffprobe: false, missing: ['randclip'], hint: e.message };
  }
}
let toolsCache = null, toolsAt = 0;
function cachedTools() {
  if (toolsCache && Date.now() - toolsAt < 5000) return toolsCache;
  toolsCache = checkTools();
  toolsAt = Date.now();
  return toolsCache;
}

// Событие randclip → событие задачи в том виде, который читает fetch-ui.js. Лишнее – null.
function toJobEvent(ev) {
  if (!ev) return null;
  if (ev.type === 'video') return { type: 'video', i: ev.index, url: ev.url, duration: ev.duration };
  if (ev.type === 'clip') return { type: 'clip', name: ev.file, span: ev.start + '–' + ev.end + ' с' };
  if (ev.type === 'progress') {
    return { type: 'progress', i: ev.index, part: ev.part, parts: ev.parts, downloaded: ev.downloaded, size: ev.size, speed: ev.speed, eta: ev.eta };
  }
  if (ev.type === 'skip') return { type: 'log', text: '[' + ev.index + '] пропуск: ' + ev.reason + ': ' + ev.url };
  if (ev.type === 'warn') return { type: 'log', text: ev.message };
  if (ev.type === 'search') return { type: 'log', text: 'Поиск «' + ev.query + '»: взято ' + ev.picked + ' из ' + ev.found };
  return null;
}

function stamp(d = new Date()) {
  const p = n => String(n).padStart(2, '0');
  return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
}

// Движок задачи: randclip.fetchClips в новой папке <clipsDir>/<дата-время>. `load` подменяется в тестах.
function randclipRunner(clipsDir, load = loadRandclip) {
  return async function run(input, emit, signal) {
    const out = path.join(clipsDir, stamp());
    try {
      const res = await load().fetchClips({
        urls: input.urls, query: input.mode === 'search' ? input.query : '', count: DEFAULTS.count,
        per: input.per, len: input.len, height: input.height, out,
      }, { signal, onEvent: ev => { const e = toJobEvent(ev); if (e) emit(e); } });
      return { dir: res.dir, files: res.files };
    } catch (e) {
      try { fs.rmdirSync(out); } catch { /* папки нет или в ней есть файлы */ }
      throw e;
    }
  };
}

// Очередь создаётся при первом обращении: страница открывается и без randclip, ошибка видна в /clips/status.
function lazyQueue(clipsDir) {
  let real = null;
  const get = () => real || (real = loadRandclip().createJobs({ runner: randclipRunner(clipsDir) }));
  return {
    start: opts => get().start(opts), get: (id, from) => get().get(id, from),
    cancel: id => get().cancel(id), busy: () => (real ? real.busy() : false),
  };
}

// ---------- HTTP ----------
// Опубликованная страница (https://cut.screwify.space) ходит сюда со своего адреса: ей разрешены запросы
// и чтение ответов. Другие источники (BEATCUT_ORIGINS – через запятую) задаются явно; всё остальное – только свой адрес.
const PAGE_ORIGINS = ['https://cut.screwify.space'];
function trustedOrigins() {
  return PAGE_ORIGINS.concat((process.env.BEATCUT_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean));
}
function sameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  if (trustedOrigins().includes(origin)) return true;
  try { return new URL(origin).host === (req.headers.host || ''); } catch { return false; }
}
// CORS и Private Network Access для доверенной страницы; предзапрос (OPTIONS) получает 204.
function cors(req, res) {
  const origin = req.headers.origin;
  if (!origin || !trustedOrigins().includes(origin)) return false;
  res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Vary', 'Origin');
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Private-Network', 'true');
    res.setHeader('Access-Control-Max-Age', '600');
  }
  return true;
}
function readBody(req, res, done) {
  let size = 0, chunks = [], closed = false;
  req.on('data', c => {
    if (closed) return;
    size += c.length;
    if (size > MAX_BODY) { closed = true; send(res, 413, 'слишком много'); req.destroy(); return; }
    chunks.push(c);
  });
  req.on('end', () => { if (!closed) done(Buffer.concat(chunks).toString('utf8')); });
}

function createHandler({ clipsDir = CLIPS, jobs, tools = cachedTools } = {}) {
  const queue = jobs || lazyQueue(clipsDir);

  return function handler(req, res) {
    let url;
    try { url = new URL(req.url, 'http://x'); } catch { return send(res, 400, 'bad request'); }
    const p = url.pathname;

    cors(req, res);
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

    if (p === '/clips/status') {
      return sendJson(res, 200, { ok: true, tools: tools(), busy: queue.busy(), latest: listClips(clipsDir) });
    }
    if (p === '/clips/list.json') return sendJson(res, 200, listClips(clipsDir));

    if (p === '/clips/jobs' && req.method === 'POST') {
      if (!sameOrigin(req)) return sendJson(res, 403, { error: { code: 'origin', message: 'чужой источник' } });
      if (!/^application\/json\b/.test(req.headers['content-type'] || '')) {
        return sendJson(res, 415, { error: { code: 'type', message: 'нужен application/json' } });
      }
      return readBody(req, res, body => {
        let input;
        try { input = normalize(JSON.parse(body)); }
        catch (e) {
          const code = e.code || 'json';
          return sendJson(res, 400, { error: { code, message: code === 'json' ? 'не разобрать запрос' : e.message } });
        }
        const missing = tools().missing;
        if (missing.length) {
          return sendJson(res, 412, { error: { code: 'tools', message: 'Не найдено: ' + missing.join(', '), missing } });
        }
        let job;
        try { job = queue.start(input); }
        catch (e) {
          if (e.code === 'busy') return sendJson(res, 409, { error: { code: 'busy', message: 'нарезка уже идёт' } });
          return sendJson(res, 500, { error: { code: 'other', message: String((e && e.message) || e) } });
        }
        sendJson(res, 200, { job });
      });
    }

    let m = /^\/clips\/jobs\/([^/]+)$/.exec(p);
    if (m && req.method === 'GET') {
      const job = queue.get(decodeURIComponent(m[1]), Number(url.searchParams.get('from')) || 0);
      return job ? sendJson(res, 200, { job }) : sendJson(res, 404, { error: { code: 'notFound', message: 'нет такой задачи' } });
    }
    m = /^\/clips\/jobs\/([^/]+)\/cancel$/.exec(p);
    if (m && req.method === 'POST') {
      if (!sameOrigin(req)) return sendJson(res, 403, { error: { code: 'origin', message: 'чужой источник' } });
      const job = queue.cancel(decodeURIComponent(m[1]));
      return job ? sendJson(res, 200, { job }) : sendJson(res, 404, { error: { code: 'notFound', message: 'нет такой задачи' } });
    }

    try {
      if (p.startsWith('/clips/')) {
        const { dir } = listClips(clipsDir);
        const file = dir && safeJoin(dir, p.slice(7));
        return file ? sendFile(res, file) : send(res, 404, 'not found');
      }
      const file = safeJoin(ROOT, p === '/' ? 'index.html' : p.slice(1));
      return file ? sendFile(res, file) : send(res, 403, 'forbidden');
    } catch { return send(res, 400, 'bad request'); }
  };
}

const handler = createHandler();

if (typeof module !== 'undefined') module.exports = { handler, createHandler, listClips, trustedOrigins, latestDir, safeJoin, checkTools, randclipRunner, toJobEvent, stamp };
if (require.main === module) {
  const port = Number(process.argv[2]) || 8794;
  const host = process.env.HOST || '127.0.0.1';
  http.createServer(handler).listen(port, host, () => console.log(`beatcut: http://${host === '127.0.0.1' ? 'localhost' : host}:${port}/  (нарезки: ${CLIPS})`));
}
