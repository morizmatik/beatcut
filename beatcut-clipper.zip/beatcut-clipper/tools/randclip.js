// Загрузчик кусков из YouTube – отдельный проект randclip (не в этом репозитории).
// Ищем его: RANDCLIP_DIR, соседняя папка рядом с screwed-music, глобальная установка (npm i -g).
const path = require('path');

const INSTALL = 'Нужен randclip: склонируйте его рядом с screwed-music (или задайте RANDCLIP_DIR, или поставьте npm i -g)';

function loadRandclip(candidates) {
  const tries = candidates || [process.env.RANDCLIP_DIR, path.join(__dirname, '..', 'randclip'), path.join(__dirname, '..', '..', '..', '..', 'randclip'), 'randclip'];
  for (const t of tries.filter(Boolean)) {
    try { return require(t); } catch (e) { if (e.code !== 'MODULE_NOT_FOUND') throw e; }
  }
  throw Object.assign(new Error(INSTALL), { code: 'randclip' });
}

if (typeof module !== 'undefined') module.exports = { loadRandclip, INSTALL };
