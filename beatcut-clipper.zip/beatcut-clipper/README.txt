Beatcut Clipper – нарезка из YouTube для https://beatcut.screwify.space/

1. Установите Node.js, yt-dlp и ffmpeg:  brew install node yt-dlp ffmpeg
2. Распакуйте архив туда, где он будет лежать постоянно, и запустите install.command (двойной щелчок
   или `sh install.command`). Папку потом не перемещайте – приложение ссылается на неё.
3. На странице Beatcut раскройте «Нарезки из YouTube» и нажмите «Запустить нарезчик»;
   браузер один раз спросит, открыть ли Beatcut Clipper.

Помощник слушает только 127.0.0.1:8794 и отвечает только странице beatcut.screwify.space.
Нарезки – в ~/Movies/Beatcut Clips (другая папка: переменная BEATCUT_CLIPS).
Удаление: приложение ~/Applications/Beatcut Clipper.app и эта папка.
