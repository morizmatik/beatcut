// Разбор того, что вставили в форму нарезок: строки-ссылки (можно с # комментариями) или поисковый запрос.
// Чистая часть без DOM и сети – одна и та же на странице и в tools/serve.js.
(function (root) {
  'use strict';
  const DEFAULTS = Object.freeze({ per: 3, len: 4, height: 1080, count: 5 });
  const LIMITS = Object.freeze({ per: [1, 10], len: [1, 30], height: [240, 2160], urls: 20, text: 4000, query: 120 });

  function fail(code, extra) {
    const e = new Error(code);
    e.code = code;
    if (extra) Object.assign(e, extra);
    return e;
  }

  // Строки списка: без # хвостов, без пустых, без пробелов по краям.
  function parseList(text) {
    return String(text == null ? '' : text).split(/\r?\n/)
      .map(line => line.replace(/#.*$/, '').trim())
      .filter(Boolean);
  }

  const SCHEME = /^https?:\/\//i;
  const DOMAIN = /^[\w-]+(\.[\w-]+)+(\/|$)/;

  // Ссылка без схемы (youtu.be/…) дополняется https, всё остальное возвращается как есть.
  function toUrl(line) {
    return SCHEME.test(line) ? line : (DOMAIN.test(line) ? 'https://' + line : line);
  }

  function isUrl(s) {
    try { return SCHEME.test(s) && !!new URL(s).hostname; } catch { return false; }
  }

  function intIn(value, name, range, fallback) {
    if (value === undefined || value === null || value === '') return fallback;
    const n = Math.round(Number(value));
    if (!Number.isFinite(n) || n < range[0] || n > range[1]) throw fail(name);
    return n;
  }

  // → { mode:'links', urls:[…] } или { mode:'search', query:'…' } плюс per/len/height.
  function normalize(input) {
    const opts = input || {};
    const text = String(opts.text == null ? '' : opts.text).trim();
    if (!text) throw fail('empty');
    if (text.length > LIMITS.text) throw fail('long');
    const per = intIn(opts.per, 'per', LIMITS.per, DEFAULTS.per);
    const len = intIn(opts.len, 'len', LIMITS.len, DEFAULTS.len);
    const height = intIn(opts.height, 'height', LIMITS.height, DEFAULTS.height);
    const lines = parseList(text);
    if (!lines.length) throw fail('empty');

    if (opts.mode === 'search') {
      const query = lines.join(' ').replace(/\s+/g, ' ').trim();
      if (query.length > LIMITS.query) throw fail('queryLong');
      return { mode: 'search', urls: [], query, per, len, height };
    }

    const urls = lines.map(toUrl);
    if (urls.length > LIMITS.urls) throw fail('tooMany');
    for (const u of urls) if (!isUrl(u)) throw fail('notUrl', { line: u.slice(0, 80) });
    return { mode: 'links', urls, query: '', per, len, height };
  }

  const api = { DEFAULTS, LIMITS, parseList, toUrl, isUrl, normalize };
  root.beatcutFetchModel = api;
  if (typeof module !== 'undefined') module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
