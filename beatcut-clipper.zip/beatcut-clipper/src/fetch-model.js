// Разбор того, что вставили в форму нарезок: строки-ссылки (можно с # комментариями) или поисковый запрос.
// Чистая часть без DOM и сети – одна и та же на странице и в tools/serve.js.
(function (root) {
  'use strict';
  const DEFAULTS = Object.freeze({ per: 3, len: 4, height: 1080, count: 5 });
  const LIMITS = Object.freeze({ per: [1, 10], len: [1, 30], height: [240, 2160], urls: 20, text: 4000, query: 120 });

  function fail(code, extra) {
    const e = new Error(code);
    e.code = code;
    if (extra) Object.assign(e, extra);
    return e;
  }

  // Строки списка: без # хвостов, без пустых, без пробелов по краям.
  function parseList(text) {
    return String(text == null ? '' : text).split(/\r?\n/)
      .map(line => line.replace(/#.*$/, '').trim())
      .filter(Boolean);
  }

  const SCHEME = /^https?:\/\//i;
  const DOMAIN = /^[\w-]+(\.[\w-]+)+(\/|$)/;

  // Ссылка без схемы (youtu.be/…) дополняется https, всё остальное возвращается как есть.
  function toUrl(line) {
    return SCHEME.test(line) ? line : (DOMAIN.test(line) ? 'https://' + line : line);
  }

  function isUrl(s) {
    try { return SCHEME.test(s) && !!new URL(s).hostname; } catch { return false; }
  }

  function intIn(value, name, range, fallback) {
    if (value === undefined || value === null || value === '') return fallback;
    const n = Math.round(Number(value));
    if (!Number.isFinite(n) || n < range[0] || n > range[1]) throw fail(name);
    return n;
  }

  // → { mode:'links', urls:[…] } или { mode:'search', query:'…' } плюс per/len/height.
  function normalize(input) {
    const opts = input || {};
    const text = String(opts.text == null ? '' : opts.text).trim();
    if (!text) throw fail('empty');
    if (text.length > LIMITS.text) throw fail('long');
    const per = intIn(opts.per, 'per', LIMITS.per, DEFAULTS.per);
    const len = intIn(opts.len, 'len', LIMITS.len, DEFAULTS.len);
    const height = intIn(opts.height, 'height', LIMITS.height, DEFAULTS.height);
    const lines = parseList(text);
    if (!lines.length) throw fail('empty');

    if (opts.mode === 'search') {
      const query = lines.join(' ').replace(/\s+/g, ' ').trim();
      if (query.length > LIMITS.query) throw fail('queryLong');
      return { mode: 'search', urls: [], query, per, len, height };
    }

    const urls = lines.map(toUrl);
    if (urls.length > LIMITS.urls) throw fail('tooMany');
    for (const u of urls) if (!isUrl(u)) throw fail('notUrl', { line: u.slice(0, 80) });
    return { mode: 'links', urls, query: '', per, len, height };
  }

  // Размер в байтах → «12,3 МБ»; units – названия Б, КБ, МБ, ГБ (по языку), sep – десятичный разделитель.
  function formatBytes(n, units, sep = '.') {
    if (!(n >= 0) || !Number.isFinite(n)) return '';
    let v = n, i = 0;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
    const s = i === 0 || v >= 100 ? String(Math.round(v)) : v.toFixed(1);
    return s.replace('.', sep) + ' ' + units[i];
  }

  // Секунды → «5 с», «1 м 05 с»; units – названия секунд и минут.
  function formatEta(sec, units) {
    if (!(sec >= 0) || !Number.isFinite(sec)) return '';
    const s = Math.round(sec);
    if (s < 60) return s + ' ' + units[0];
    return Math.floor(s / 60) + ' ' + units[1] + ' ' + String(s % 60).padStart(2, '0') + ' ' + units[0];
  }

  // Доля куска (0..1) по событию прогресса; неизвестный размер – 0.
  function segmentFraction(ev) {
    if (!ev || !(ev.size > 0) || !(ev.downloaded >= 0)) return 0;
    return Math.min(1, ev.downloaded / ev.size);
  }

  // Ответ /clips/status (tools) → { ready, key, args }: можно ли нарезать, а если нет – какую строку показать.
  // tools == null – помощник не отвечает. remote – страница опубликована (помощник на компьютере пользователя).
  function toolsState(tools, remote) {
    if (!tools) return { ready: false, key: remote ? 'fetch.noHelper' : 'fetch.noApi', args: [] };
    const missing = Array.isArray(tools.missing) ? tools.missing : [];
    if (!missing.length) return { ready: true, key: null, args: [] };
    if (missing.includes('randclip')) return { ready: false, key: remote ? 'fetch.err.randclipHelper' : 'fetch.err.randclip', args: [] };
    const cmd = /:\s*(.+)$/.exec(String(tools.hint || '').trim());
    return cmd ? { ready: false, key: 'fetch.err.toolsCmd', args: [missing.join(', '), cmd[1]] }
      : { ready: false, key: 'fetch.err.tools', args: [missing.join(', ')] };
  }

  const api = { DEFAULTS, LIMITS, parseList, toUrl, isUrl, normalize, formatBytes, formatEta, segmentFraction, toolsState };
  root.beatcutFetchModel = api;
  if (typeof module !== 'undefined') module.exports = api;
})(typeof self !== 'undefined' ? self : globalThis);
