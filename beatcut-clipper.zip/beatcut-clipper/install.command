#!/bin/sh
# Установка нарезчика Beatcut (macOS). Двойной щелчок по файлу или: sh install.command
# Что делает: докачивает randclip (загрузчик из YouTube), создаёт приложение «Beatcut Clipper» в ~/Applications
# и регистрирует ссылку beatcut://, чтобы кнопка «Запустить нарезчик» на beatcut.screwify.space поднимала помощника.
# Нужны Node.js, yt-dlp и ffmpeg (brew install node yt-dlp ffmpeg). Папка со скриптом должна остаться на месте.
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

NODE=$(command -v node || true)
[ -n "$NODE" ] || { echo "Не найден Node.js – поставьте: brew install node (https://nodejs.org)"; exit 1; }

if [ ! -f "$HERE/randclip/package.json" ]; then
  echo "Скачиваю randclip…"
  if command -v git >/dev/null 2>&1; then
    git clone --depth 1 https://github.com/morizmatik/randclip "$HERE/randclip"
  else
    mkdir -p "$HERE/randclip"
    curl -fsSL https://github.com/morizmatik/randclip/archive/refs/heads/main.tar.gz | tar xz --strip-components=1 -C "$HERE/randclip"
  fi
fi

for tool in yt-dlp ffmpeg ffprobe; do
  command -v "$tool" >/dev/null 2>&1 || echo "Не найден $tool – поставьте: brew install yt-dlp ffmpeg"
done

APP="$HOME/Applications/Beatcut Clipper.app"
mkdir -p "$APP/Contents/MacOS"
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>Beatcut Clipper</string>
  <key>CFBundleIdentifier</key><string>space.screwify.beatcut.clipper</string>
  <key>CFBundleExecutable</key><string>clipper</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleVersion</key><string>1</string>
  <key>LSUIElement</key><true/>
  <key>CFBundleURLTypes</key><array><dict>
    <key>CFBundleURLName</key><string>Beatcut Clipper</string>
    <key>CFBundleURLSchemes</key><array><string>beatcut</string></array>
  </dict></array>
</dict></plist>
PLIST
cat > "$APP/Contents/MacOS/clipper" <<LAUNCHER
#!/bin/sh
# Запускает помощника, если он ещё не работает (ссылка beatcut://start или двойной щелчок).
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:\$PATH"
export BEATCUT_CLIPS="\${BEATCUT_CLIPS:-\$HOME/Movies/Beatcut Clips}"
curl -s -m 1 http://127.0.0.1:8794/clips/status >/dev/null 2>&1 && exit 0
mkdir -p "\$HOME/Library/Logs" "\$BEATCUT_CLIPS"
nohup "$NODE" "$HERE/tools/serve.js" 8794 </dev/null >>"\$HOME/Library/Logs/beatcut-clipper.log" 2>&1 &
LAUNCHER
chmod +x "$APP/Contents/MacOS/clipper"
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$APP"

echo "Готово. Нарезки сохраняются в ~/Movies/Beatcut Clips, журнал – ~/Library/Logs/beatcut-clipper.log."
echo "Откройте https://beatcut.screwify.space/ и нажмите «Запустить нарезчик»."
